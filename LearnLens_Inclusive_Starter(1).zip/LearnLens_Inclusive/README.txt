LEARNLENS INCLUSIVE — STARTER PROTOTYPE

WHAT'S INCLUDED
- Responsive web app interface for phones, tablets, and laptops
- Accessibility settings: larger text, high contrast, reduced motion, optional voice feedback
- English, Telugu, and Hindi interface text for the main screen
- Communication board with tap-to-build phrases and browser speech output
- Sample learning activities
- Screening information section with a clear no-diagnosis notice

HOW TO RUN
1. Extract the ZIP file.
2. Open the LearnLens_Inclusive folder.
3. Double-click index.html to open it in a modern browser.
4. For development, open the folder in Visual Studio Code.
5. You can install the VS Code "Live Server" extension and choose "Open with Live Server".

IMPORTANT LIMITATIONS
This is an early front-end prototype. It does not have a database, user accounts, cloud storage,
real medical screening, or a clinician/teacher reporting backend. The sample activities are not
validated screening tests and must not be used to diagnose a condition.
Before piloting with children, test with disabled users and accessibility specialists, obtain
appropriate parent/guardian consent, minimize data collection, and have qualified professionals
review any screening workflows. Browser text-to-speech depends on device/browser language support.

FILES
- index.html : page structure
- styles.css : visual design and responsive layout
- app.js     : interactivity, language switching, accessibility controls, sample tools
