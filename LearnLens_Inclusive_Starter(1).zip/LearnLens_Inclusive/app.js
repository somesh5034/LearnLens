const translations = {
  en: {
    eyebrow:"LEARNING THAT INCLUDES EVERYONE", heroTitle:"Different abilities.<br><span>Equal opportunities.</span>",
    heroText:"Learn, communicate, and explore at your own pace. Choose the tools that work best for you.",
    start:"Explore activities →", listen:"Listen to welcome", quickTitle:"What would you like to do?",
    quickSub:"Choose a tool. You can change accessibility settings any time.", learnTitle:"Learn & Play",
    learnDesc:"Try friendly learning activities at your own pace.", explore:"Explore activities →",
    commTitle:"Communication Board", commDesc:"Tap pictures or phrases to communicate without speaking.",
    openTool:"Open tool →", accessTitle:"Accessibility Tools", accessDesc:"Adjust text, contrast, motion, and reading support.",
    customize:"Customize →", screenTitle:"Screening Activities", screenDesc:"Try simple activities that may suggest when a professional check could help.",
    learnMore:"Learn more →", readyTitle:"Your next step starts here",
    readyText:"Choose one of the tools above to get started. There is no rush.",
    promiseTitle:"Your needs come first.", promiseText:"You can pause, change settings, or leave an activity at any time. Screening activities do not diagnose a condition. A qualified professional can help interpret concerns."
  },
  te: {
    eyebrow:"అందరికీ అందుబాటులో ఉండే అభ్యాసం", heroTitle:"విభిన్న సామర్థ్యాలు.<br><span>సమాన అవకాశాలు.</span>",
    heroText:"మీ వేగంతో నేర్చుకోండి, సంభాషించండి, కొత్త విషయాలను అన్వేషించండి. మీకు అనుకూలమైన సాధనాలను ఎంచుకోండి.",
    start:"కార్యకలాపాలు చూడండి →", listen:"స్వాగత సందేశం వినండి", quickTitle:"మీరు ఏమి చేయాలనుకుంటున్నారు?",
    quickSub:"ఒక సాధనాన్ని ఎంచుకోండి. ఎప్పుడైనా యాక్సెసిబిలిటీ సెట్టింగ్‌లను మార్చవచ్చు.",
    learnTitle:"నేర్చుకోండి & ఆడండి", learnDesc:"మీ వేగంతో సరదా అభ్యాస కార్యకలాపాలు ప్రయత్నించండి.",
    explore:"కార్యకలాపాలు చూడండి →", commTitle:"సంభాషణ బోర్డు",
    commDesc:"మాట్లాడకుండానే చిత్రాలు లేదా వాక్యాలను తాకి తెలియజేయండి.", openTool:"సాధనాన్ని తెరవండి →",
    accessTitle:"యాక్సెసిబిలిటీ సాధనాలు", accessDesc:"అక్షరాల పరిమాణం, కాంట్రాస్ట్, కదలికలను మార్చండి.",
    customize:"మార్చండి →", screenTitle:"స్క్రీనింగ్ కార్యకలాపాలు",
    screenDesc:"నిపుణుడి సహాయం అవసరమా అని గుర్తించడంలో తోడ్పడే సాధారణ కార్యకలాపాలు.",
    learnMore:"మరింత తెలుసుకోండి →", readyTitle:"మీ తదుపరి అడుగు ఇక్కడ మొదలవుతుంది",
    readyText:"ప్రారంభించడానికి పై సాధనాల్లో ఒకదాన్ని ఎంచుకోండి. తొందర అవసరం లేదు.",
    promiseTitle:"మీ అవసరాలే ముఖ్యం.", promiseText:"మీరు ఎప్పుడైనా ఆపవచ్చు లేదా సెట్టింగ్‌లను మార్చవచ్చు. స్క్రీనింగ్ కార్యకలాపాలు వ్యాధిని నిర్ధారించవు. సందేహాలుంటే అర్హత కలిగిన నిపుణుడిని సంప్రదించండి."
  },
  hi: {
    eyebrow:"हर किसी के लिए सीखना", heroTitle:"अलग क्षमताएँ।<br><span>समान अवसर।</span>",
    heroText:"अपनी गति से सीखें, बातचीत करें और नई चीज़ें खोजें। अपने लिए सही सुविधाएँ चुनें।",
    start:"गतिविधियाँ देखें →", listen:"स्वागत संदेश सुनें", quickTitle:"आप क्या करना चाहेंगे?",
    quickSub:"कोई सुविधा चुनें। आप कभी भी एक्सेसिबिलिटी सेटिंग बदल सकते हैं।",
    learnTitle:"सीखें और खेलें", learnDesc:"अपनी गति से मज़ेदार सीखने वाली गतिविधियाँ आज़माएँ।",
    explore:"गतिविधियाँ देखें →", commTitle:"संचार बोर्ड",
    commDesc:"बिना बोले बातचीत करने के लिए चित्रों या वाक्यों पर टैप करें।", openTool:"टूल खोलें →",
    accessTitle:"एक्सेसिबिलिटी टूल", accessDesc:"टेक्स्ट, कंट्रास्ट, गति और पढ़ने की सुविधाएँ बदलें।",
    customize:"बदलें →", screenTitle:"स्क्रीनिंग गतिविधियाँ",
    screenDesc:"सरल गतिविधियाँ जो यह संकेत दे सकती हैं कि विशेषज्ञ की जाँच मददगार होगी।",
    learnMore:"और जानें →", readyTitle:"आपका अगला कदम यहाँ से शुरू होता है",
    readyText:"शुरू करने के लिए ऊपर दिए गए टूल में से एक चुनें। कोई जल्दी नहीं है।",
    promiseTitle:"आपकी ज़रूरतें सबसे पहले।", promiseText:"आप किसी भी समय रुक सकते हैं या सेटिंग बदल सकते हैं। स्क्रीनिंग गतिविधियाँ किसी स्थिति का निदान नहीं करतीं। चिंता होने पर योग्य विशेषज्ञ से सलाह लें।"
  }
};

const activityArea = document.getElementById('activityArea');
const settingsDialog = document.getElementById('settingsDialog');
const speak = (text) => {
  if (!('speechSynthesis' in window)) {
    alert('Spoken feedback is not supported in this browser. You can still use all on-screen text.');
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  const lang = document.getElementById('language').value;
  utterance.lang = lang === 'te' ? 'te-IN' : lang === 'hi' ? 'hi-IN' : 'en-IN';
  window.speechSynthesis.speak(utterance);
};

function renderPlaceholder(title, text) {
  activityArea.innerHTML = `<div class="activity-placeholder"><div class="placeholder-icon" aria-hidden="true">✨</div><h2 id="activityTitle">${title}</h2><p>${text}</p></div>`;
}
function openActivity(type) {
  if (type === 'learning') {
    activityArea.innerHTML = `<div class="activity-content"><p class="eyebrow">LEARN & PLAY</p><h2 id="activityTitle">Choose a friendly activity</h2><p class="intro">No scores, no pressure. These sample activities are designed to be explored at your own pace.</p><div class="tool-grid">
      <button class="tool-tile" data-game="letters"><span aria-hidden="true">🔤</span>Letter match</button>
      <button class="tool-tile" data-game="memory"><span aria-hidden="true">🧠</span>Memory pairs</button>
      <button class="tool-tile" data-game="patterns"><span aria-hidden="true">🔷</span>Find the pattern</button>
    </div><div id="gameResult" class="result-box" hidden role="status"></div><p class="small-note">Activities are demonstrations. Adjustments and more content can be added as the project grows.</p></div>`;
    activityArea.querySelectorAll('[data-game]').forEach(btn => btn.addEventListener('click', () => playGame(btn.dataset.game)));
  } else if (type === 'communication') {
    activityArea.innerHTML = `<div class="activity-content"><p class="eyebrow">COMMUNICATION SUPPORT</p><h2 id="activityTitle">What would you like to say?</h2><p class="intro">Tap one or more cards. You can show the message or ask the device to read it aloud.</p><div class="communication-output" id="communicationOutput" role="status" aria-live="polite">Your message will appear here.</div><div class="phrase-grid">
      <button class="phrase-button" data-phrase="I need help"><span aria-hidden="true">🆘</span>I need help</button>
      <button class="phrase-button" data-phrase="I feel happy"><span aria-hidden="true">😊</span>I feel happy</button>
      <button class="phrase-button" data-phrase="I need a break"><span aria-hidden="true">⏸️</span>I need a break</button>
      <button class="phrase-button" data-phrase="Please repeat"><span aria-hidden="true">🔁</span>Please repeat</button>
      <button class="phrase-button" data-phrase="Yes"><span aria-hidden="true">✅</span>Yes</button>
      <button class="phrase-button" data-phrase="No"><span aria-hidden="true">❌</span>No</button>
      <button class="phrase-button" data-phrase="I am thirsty"><span aria-hidden="true">💧</span>I am thirsty</button>
      <button class="phrase-button" data-phrase="I do not understand"><span aria-hidden="true">💭</span>I do not understand</button>
    </div><div class="inline-actions"><button class="button button-primary" id="speakMessage">🔊 Read message</button><button class="button button-soft" id="clearMessage">Clear message</button></div></div>`;
    const chosen = [];
    const output = document.getElementById('communicationOutput');
    activityArea.querySelectorAll('[data-phrase]').forEach(btn => btn.addEventListener('click', () => {
      chosen.push(btn.dataset.phrase); output.textContent = chosen.join('. ') + '.';
      if (document.getElementById('voiceFeedback').checked) speak(btn.dataset.phrase);
    }));
    document.getElementById('speakMessage').addEventListener('click', () => chosen.length ? speak(chosen.join('. ')) : speak('Choose a phrase first.'));
    document.getElementById('clearMessage').addEventListener('click', () => { chosen.length = 0; output.textContent = 'Your message will appear here.'; });
  } else if (type === 'screening') {
    activityArea.innerHTML = `<div class="activity-content"><p class="eyebrow">LEARNLENS SCREENING</p><h2 id="activityTitle">Screening support, not diagnosis</h2><p class="intro">LearnLens is intended to help adults notice when a child may benefit from a professional check. This demo does not assess health or produce a medical result.</p><div class="tool-grid">
      <div class="tool-tile" tabindex="0"><span aria-hidden="true">👁️</span>Vision and contrast</div>
      <div class="tool-tile" tabindex="0"><span aria-hidden="true">🎨</span>Colour vision</div>
      <div class="tool-tile" tabindex="0"><span aria-hidden="true">👂</span>Hearing access</div>
      <div class="tool-tile" tabindex="0"><span aria-hidden="true">📖</span>Reading support</div>
      <div class="tool-tile" tabindex="0"><span aria-hidden="true">🎯</span>Attention support</div>
    </div><div class="result-box"><strong>Important:</strong> A game cannot confirm a disability or medical condition. If you have a concern, contact a qualified health or education professional. Activities must be adapted so that a child's disability does not unfairly affect the result.</div></div>`;
  }
  activityArea.scrollIntoView({behavior: document.body.classList.contains('reduce-motion') ? 'auto' : 'smooth', block:'start'});
}
function playGame(game) {
  const box = document.getElementById('gameResult');
  box.hidden = false;
  if (game === 'letters') {
    box.innerHTML = `<strong>Letter match</strong><p>Which letter matches the target <strong>A</strong>?</p><div class="inline-actions"><button class="button button-soft" data-answer="wrong">B</button><button class="button button-soft" data-answer="right">A</button><button class="button button-soft" data-answer="wrong">C</button></div>`;
    box.querySelectorAll('[data-answer]').forEach(b => b.addEventListener('click', () => { box.innerHTML = b.dataset.answer === 'right' ? '<strong>Well done!</strong><p>You found the matching letter. You can try again whenever you like.</p>' : '<strong>Good try!</strong><p>Look for the same letter shape. You can try again.</p><button class="button button-soft" id="retry">Try again</button>'; const retry=document.getElementById('retry'); if(retry) retry.addEventListener('click',()=>playGame('letters')); }));
  } else if (game === 'memory') {
    box.innerHTML = '<strong>Memory pairs</strong><p>Remember: a pair means two things that are the same. This demo is ready for a full card-matching game.</p>';
  } else {
    box.innerHTML = '<strong>Find the pattern</strong><p>Circle, square, circle, square… What comes next? <button class="button button-soft" id="patternAnswer">Circle</button></p>';
    document.getElementById('patternAnswer').addEventListener('click',()=>{box.innerHTML='<strong>Nice effort!</strong><p>For this pattern, the next shape would be a circle. Keep exploring at your own pace.</p>';});
  }
}
function openSettings() { settingsDialog.showModal(); }
document.getElementById('openSettings').addEventListener('click', openSettings);
document.getElementById('cardSettings').addEventListener('click', openSettings);
document.getElementById('startLearning').addEventListener('click', () => openActivity('learning'));
document.querySelectorAll('[data-open]').forEach(btn => btn.addEventListener('click', () => openActivity(btn.dataset.open)));
document.getElementById('speakWelcome').addEventListener('click', () => speak('Welcome to LearnLens Inclusive. Different abilities, equal opportunities. Choose the tools that work best for you.'));
document.getElementById('largeText').addEventListener('change', e => document.body.classList.toggle('large-text', e.target.checked));
document.getElementById('highContrast').addEventListener('change', e => document.body.classList.toggle('high-contrast', e.target.checked));
document.getElementById('reduceMotion').addEventListener('change', e => document.body.classList.toggle('reduce-motion', e.target.checked));
document.getElementById('resetSettings').addEventListener('click', () => {
  ['largeText','highContrast','voiceFeedback'].forEach(id => document.getElementById(id).checked = false);
  document.getElementById('reduceMotion').checked = true;
  document.body.classList.remove('large-text','high-contrast'); document.body.classList.add('reduce-motion');
});
document.getElementById('language').addEventListener('change', e => {
  const dict = translations[e.target.value] || translations.en;
  document.querySelectorAll('[data-i18n]').forEach(el => { const key=el.dataset.i18n; if(dict[key]) el.innerHTML=dict[key]; });
});
document.body.classList.add('reduce-motion');
